**Objective:** Create a simple program that defines a `Restaurant` class with properties and a default value for one of the properties. The `Restaurant` class will have three properties: `name`, `cuisine`, and `rating` (with a default value of `0`).

## Steps
1. Define the `Restaurant` class with properties: `name`, `cuisine`, and `rating`. Set the default value of `rating` to `0`.
```javascript
class Restaurant {
  constructor(name, cuisine, rating = 0) {
    this.name = name;
    this.cuisine = cuisine;
    this.rating = rating;
  }
}
```

2. Create an instance of the `Restaurant` class by initializing it with sample data, without providing a value for the `rating` property.
```javascript
const restaurant1 = new Restaurant('Pizza Palace', 'Italian');
```

3. Create another instance of the `Restaurant` class by initializing it with sample data and providing a value for the `rating` property.
```javascript
const restaurant2 = new Restaurant('Burger Central', 'American', 4.5);
```

4. Use `console.log` to output the `name`, `cuisine`, and `rating` of `restaurant1` and `restaurant2` using template literals.
```javascript
console.log(`Name: ${restaurant1.name}, Cuisine: ${restaurant1.cuisine}, Rating: ${restaurant1.rating}`);
console.log(`Name: ${restaurant2.name}, Cuisine: ${restaurant2.cuisine}, Rating: ${restaurant2.rating}`);
```

5. Run the code and examine the output.
```
Name: Pizza Palace, Cuisine: Italian, Rating: 0
Name: Burger Central, Cuisine: American, Rating: 4.5
```

<details>
<summary>Full Code</summary>

```javascript
class Restaurant {
  constructor(name, cuisine, rating = 0) {
    this.name = name;
    this.cuisine = cuisine;
    this.rating = rating;
  }
}

const restaurant1 = new Restaurant('Pizza Palace', 'Italian');
const restaurant2 = new Restaurant('Burger Central', 'American', 4.5);

console.log(`Name: ${restaurant1.name}, Cuisine: ${restaurant1.cuisine}, Rating: ${restaurant1.rating}`);
console.log(`Name: ${restaurant2.name}, Cuisine: ${restaurant2.cuisine}, Rating: ${restaurant2.rating}`);
```
</details>
