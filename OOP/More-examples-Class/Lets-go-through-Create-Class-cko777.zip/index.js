let sister = {
  name: "Mary",
  age: 23,
  celebrateBirthday: function() {
    return this.age = this.age + 1;
  }
}

console.log(sister.name)
console.log(sister.celebrateBirthday())

let brother = {
  name: "John",
  hobby: "volleyball",
  age: 24,
  aboutSelf: function() {
    return (`${this.name} is ${this.age} and he likes ${this.hobby}`)
  }
}

console.log(brother.aboutSelf())