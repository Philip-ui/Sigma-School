**Objective:** Create a simple program that defines a basic user class named `User` with its properties, initializes an instance of that class with data, and outputs its properties using console.log. The User class will have three properties: `firstName`, `lastName`, and `age`.

## Steps
1. Define a simple `User` class with properties: `firstName`, `lastName`, and `age`.
```javascript
class User {
  constructor(firstName, lastName, age) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.age = age;
  }
}
```

2. Create an instance of the `User` class by initializing it with sample data.
```javascript
const user = new User('John', 'Doe', 25);
```

3. Use `console.log` to output the `firstName`, `lastName`, and `age` of `user` using template literals.
```javascript
console.log(`First Name: ${user.firstName}`);
console.log(`Last Name: ${user.lastName}`);
console.log(`Age: ${user.age}`);
```

4. Run the code and examine the output.
```
First Name: John
Last Name: Doe
Age: 25
```

<details>
<summary>Full Code</summary>

```javascript
class User {
  constructor(firstName, lastName, age) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.age = age;
  }
}

const user = new User('John', 'Doe', 25);

console.log(`First Name: ${user.firstName}`);
console.log(`Last Name: ${user.lastName}`);
console.log(`Age: ${user.age}`);
```
</details>
