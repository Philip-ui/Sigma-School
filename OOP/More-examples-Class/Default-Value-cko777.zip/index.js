class Restaurant {
  constructor(name, cuisine, rating = 0) {
    this.name = name;
    this.cuisine = cuisine;
    this.rating = rating;
  }
}

const restaurant1 = new Restaurant('Pizza Palace', 'Italian');
const restaurant2 = new Restaurant('Burger Central', 'American', 4.5);

console.log(`Name: ${restaurant1.name}, Cuisine: ${restaurant1.cuisine}, Rating: ${restaurant1.rating}`);
console.log(`Name: ${restaurant2.name}, Cuisine: ${restaurant2.cuisine}, Rating: ${restaurant2.rating}`);