class Team {
  constructor(name) {
    this.name = name;
    this.member = [];
  }

  addMember(memberName) {
    this.member.push(memberName);
    console.log(`Member ${memberName} has joined team ${this.name}.`);
  }
}

const basketballTeam = new Team('Hoop Stars');

console.log(`Team Name: ${basketballTeam.name}`);
console.log(`Team Members: ${basketballTeam.members}`);

basketballTeam.addMember('John');
basketballTeam.addMember('Jane');
