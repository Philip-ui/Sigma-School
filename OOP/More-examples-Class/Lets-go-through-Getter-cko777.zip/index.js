class Rectangle {
  constructor(length, width) {
    this.length = length;
    this.width = width;
  }

  get area() {
    return this.length * this.width;
  }
}

const rectangle1 = new Rectangle(10, 5);

console.log(`Length: ${rectangle1.length}`);
console.log(`Width: ${rectangle1.width}`);
console.log(`Area: ${rectangle1.area}`);