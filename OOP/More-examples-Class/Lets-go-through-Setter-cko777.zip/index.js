class Product {
  constructor(name, price, available) {
    this.name = name;
    this.price = price;
    this.available = available;
  }

  setPrice(newPrice) {
    if (newPrice > 0) {
      this.price = newPrice;
    } else {
      console.log('The price must be a positive value.');
    }
  }
}

const product = new Product('Shoes', 100, true);

console.log(`Name: ${product.name}, Price: ${product.price}, Available: ${product.available}`);

product.setPrice(80);

console.log(`Name: ${product.name}, Price: ${product.price}, Available: ${product.available}`);

product.setPrice(-10);