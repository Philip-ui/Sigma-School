class Book {
  constructor(title, author, pages) {
    this.title = title;
    this.author = author;
    this.pages = pages;
  }

  read() {
    console.log(`You are reading ${this.title} by ${this.author}.`)
  }
}

const book = new Book('The Catcher in the Rye', 'J.D. Salinger', 277);

console.log(`Title: ${book.title}`);
console.log(`Author: ${book.author}`);
console.log(`Pages: ${book.pages}`);

book.read();
