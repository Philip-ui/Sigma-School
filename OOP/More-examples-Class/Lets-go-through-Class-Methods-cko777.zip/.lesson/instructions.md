**Objective:** Create a simple program that defines a `Book` class with properties and a method. The `Book` class will have three properties: `title`, `author`, and `pages`. It will also have a method called `read` which outputs a message when the method is called.

## Steps
1. Define the `Book` class with properties: `title`, `author`, and `pages`.
```javascript
class Book {
  constructor(title, author, pages) {
    this.title = title;
    this.author = author;
    this.pages = pages;
  }
}
```

2. Add a method called `read` inside the `Book` class.
```javascript
  read() {
    console.log(`You are reading "${this.title}" by ${this.author}.`);
  }
```

3. Create an instance of the `Book` class by initializing it with sample data.
```javascript
const book = new Book('The Catcher in the Rye', 'J.D. Salinger', 277);
```

4. Use `console.log` to output the `title`, `author`, and `pages` of `book` using template literals.
```javascript
console.log(`Title: ${book.title}`);
console.log(`Author: ${book.author}`);
console.log(`Pages: ${book.pages}`);
```

5. Call the `read` method on the `book` object.
```javascript
book.read();
```

6. Run the code and examine the output.
```
Title: The Catcher in the Rye
Author: J.D. Salinger
Pages: 277
You are reading "The Catcher in the Rye" by J.D. Salinger.
```

<details>
<summary>Full Code</summary>

```javascript
class Book {
  constructor(title, author, pages) {
    this.title = title;
    this.author = author;
    this.pages = pages;
  }

  read() {
    console.log(`You are reading "${this.title}" by ${this.author}.`);
  }
}

const book = new Book('The Catcher in the Rye', 'J.D. Salinger', 277);

console.log(`Title: ${book.title}`);
console.log(`Author: ${book.author}`);
console.log(`Pages: ${book.pages}`);

book.read();
```
</details>
