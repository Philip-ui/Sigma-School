**Objective:** Create a simple program that defines a `Product` class with properties, a setter method for updating the property, and outputting the results using console.log. This exercise explains why and when to use setters in a less technical manner.

## Steps
1. Define the `Product` class with properties: `name`, `price`, and `available`.
```javascript
class Product {
  constructor(name, price, available) {
    this.name = name;
    this.price = price;
    this.available = available;
  }
}
```

2. Add a setter method called `setPrice` inside the `Product` class, which accepts a newPrice as a parameter and sets the property `price`.
```javascript
  setPrice(newPrice) {
    if (newPrice > 0) {
      this.price = newPrice;
    } else {
      console.log('The price must be a positive value.');
    }
  }
```

3. Create an instance of the `Product` class by initializing it with sample data.
```javascript
const product = new Product('Shoes', 100, true);
```

4. Use `console.log` to output the `name`, `price`, and `available` properties of the `product`.
```javascript
console.log(`Name: ${product.name}, Price: ${product.price}, Available: ${product.available}`);
```

5. Call the `setPrice` method on the `product` object with a new positive price value.
```javascript
product.setPrice(80);
```

4. Use `console.log` to output the `name`, `price`, and `available` properties of the `product`.
```javascript
console.log(`Name: ${product.name}, Price: ${product.price}, Available: ${product.available}`);
```

6. Call the `setPrice` method on the `product` object with a new negative price value.
```javascript
product.setPrice(-10);
```

7. Run the code and examine the output.
```
Name: Shoes, Price: 100, Available: true
Name: Shoes, Price: 80, Available: true
The price must be a positive value.
```

<details>
<summary>Full Code</summary>

```javascript
class Product {
  constructor(name, price, available) {
    this.name = name;
    this.price = price;
    this.available = available;
  }

  setPrice(newPrice) {
    if (newPrice > 0) {
      this.price = newPrice;
    } else {
      console.log('The price must be a positive value.');
    }
  }
}

const product = new Product('Shoes', 100, true);

console.log(`Name: ${product.name}, Price: ${product.price}, Available: ${product.available}`);

product.setPrice(80);

console.log(`Name: ${product.name}, Price: ${product.price}, Available: ${product.available}`);

product.setPrice(-10);
```
</details>

**Why use setters?**

Setters are used to update class properties easily and safely. They allow you to control how the property is modified, offering the following benefits:

1. Validation: You can verify if the new value provided is valid before updating the property. In the example, the `setPrice` method checks if the new price is a positive value before updating the price.

2. Flexibility: By using a setter, you may perform additional actions before or after updating the property, such as logging the change or updating related properties.

3. Consistency: Setters create a standardized way for updating class properties, making it easier to manage and understand the code.

In summary, using a setter method for updating properties in the `Product` class allows for better control over how properties are modified, while providing a consistent and flexible way to handle updates.