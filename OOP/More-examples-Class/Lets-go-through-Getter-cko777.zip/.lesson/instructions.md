**Objective:** Create a simple program that defines a `Rectangle` class with properties, a getter method for calculating the area of the rectangle, and outputting the result using console.log.

## Steps
1. Define the `Rectangle` class with properties: `length` and `width`.
```javascript
class Rectangle {
  constructor(length, width) {
    this.length = length;
    this.width = width;
  }
}
```

2. Add a getter method called `area` inside the `Rectangle` class, which calculates and returns the area of the rectangle (length times width).
```javascript
  get area() {
    return this.length * this.width;
  }
```

3. Create an instance of the `Rectangle` class by initializing it with sample data.
```javascript
const rectangle1 = new Rectangle(10, 5);
```

4. Use `console.log` to output the `length`, `width`, and calculated `area` of `rectangle1` using template literals.
```javascript
console.log(`Length: ${rectangle1.length}`);
console.log(`Width: ${rectangle1.width}`);
console.log(`Area: ${rectangle1.area}`);
```

5. Run the code and examine the output.
```
Length: 10
Width: 5
Area: 50
```

<details>
<summary>Full Code</summary>

```javascript
class Rectangle {
  constructor(length, width) {
    this.length = length;
    this.width = width;
  }

  get area() {
    return this.length * this.width;
  }
}

const rectangle1 = new Rectangle(10, 5);

console.log(`Length: ${rectangle1.length}`);
console.log(`Width: ${rectangle1.width}`);
console.log(`Area: ${rectangle1.area}`);
```
</details>

In this exercise, a getter method is used instead of a normal method in the `Rectangle` class. Using a getter has certain benefits over a regular method:

1. Syntax (or vocabulary of code): When using a getter method, you can access the calculated property as if it were a regular property without needing parentheses (e.g., `rectangle1.area`). This can make the code more intuitive, cleaner, and easier to read compared to a normal method which requires parentheses (e.g., `rectangle1.calculateArea()`).

2. Encapsulation: Imagine a recipe that calls for a specific blend of spices. With a getter, your recipe can simply ask for the "spice blend" instead of having a detailed instructions on how to mix the spices. If you ever need to change the blend, you only update the getter's instructions, and it doesn't affect the main recipe. This makes it easier to maintain and change the recipe, because the instructions are separated and organized.

3. Consistency: Think of a kitchen drawer containing different types of cutlery such as spoons, forks, and knives. Using a getter method ensures that whenever you need a utensil, you pick it from the drawer in the same way as any other utensil. You don't need to use a different method just because one utensil is unique or has a particular function. This simplifies your approach since you don't need to remember which utensil requires a special way of accessing it.

In summary, using a getter method for calculating the area in the `Rectangle` class provides a more intuitive syntax and better encapsulation, while maintaining consistency when accessing class properties.