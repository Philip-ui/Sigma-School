**Objective:** Create a simple program that defines a `BankAccount` class with properties and a method. The `BankAccount` class will have two properties: `accountHolderName` and `balance`. It will also have a method called `deposit` which accepts an amount as an argument and adds it to the balance.

## Steps
1. Define the `BankAccount` class with properties: `accountHolderName` and `balance`.
```javascript
class BankAccount {
  constructor(accountHolderName, balance) {
    this.accountHolderName = accountHolderName;
    this.balance = balance;
  }
}
```

2. Add a `deposit` method inside the `BankAccount` class, which accepts an amount as a parameter and modifies the balance by adding the amount.
```javascript
  deposit(amount) {
    this.balance += amount;
    console.log(`You have deposited ${amount}. Your new balance is: ${this.balance}`);
  }
```

3. Create an instance of the `BankAccount` class by initializing it with sample data.
```javascript
const account = new BankAccount('John Doe', 1000);
```

4. Use `console.log` to output the `accountHolderName` and `balance` of `account` using template literals.
```javascript
console.log(`Account Holder Name: ${account.accountHolderName}`);
console.log(`Balance: ${account.balance}`);
```

5. Call the `deposit` method on the `account` object with an amount to deposit.
```javascript
account.deposit(500);
```

6. Run the code and examine the output.
```
Account Holder Name: John Doe
Balance: 1000
You have deposited 500. Your new balance is: 1500
```

<details>
<summary>Full Code</summary>

```javascript
class BankAccount {
  constructor(accountHolderName, balance) {
    this.accountHolderName = accountHolderName;
    this.balance = balance;
  }

  deposit(amount) {
    this.balance += amount;
    console.log(`You have deposited ${amount}. Your new balance is: ${this.balance}`);
  }
}

const account = new BankAccount('John Doe', 1000);

console.log(`Account Holder Name: ${account.accountHolderName}`);
console.log(`Balance: ${account.balance}`);

account.deposit(500);
```
</details>
